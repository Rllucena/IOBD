package apresentacao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws SQLException {
        String host = "localhost";
        String database = "bd_presenca";
        String username = "postgres";
        String password = "postgres";
        String port = "5432";

        String url = "jdbc:postgresql://"+host+":"+port+"/"+database;

        Connection conexao = DriverManager.getConnection(url, username, password);

        String sqlInsert = "INSERT INTO externo.aula (aluno_id, data, presente) values (1, CURRENT_DATE, true);";
        conexao.prepareStatement(sqlInsert).execute();

        String sql = "select * from presencas_do_david;";

        ResultSet rs = conexao.prepareStatement(sql).executeQuery();
        while(rs.next()){
            System.out.println(rs.getInt("aluno_id"));
            System.out.println(rs.getDate("data"));
            System.out.println(rs.getBoolean("presente"));
        }


      


    }
}